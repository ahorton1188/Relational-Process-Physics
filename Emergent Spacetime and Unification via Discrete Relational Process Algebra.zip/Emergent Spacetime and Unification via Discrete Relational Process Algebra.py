import networkx as nx

def run_relational_engine(initial_nodes=4, updates=5):
    """
    Simulates an expanding relational process graph where distance
    emerges from network density and entanglement connections.
    """
    G = nx.complete_graph(initial_nodes)
    print(f"--- Initial Seed Graph: Nodes={G.number_of_nodes()}, Edges={G.number_of_edges()} ---")
    
    for step in range(1, updates + 1):
        edges_to_add = []
        nodes_list = list(G.nodes())
        
        for i in range(len(nodes_list)):
            for j in range(i + 1, len(nodes_list)):
                n1, n2 = nodes_list[i], nodes_list[j]
                shared_neighbors = len(list(nx.common_neighbors(G, n1, n2)))
                if shared_neighbors > 0 and not G.has_edge(n1, n2):
                    edges_to_add.append((n1, n2))
        
        new_node = G.number_of_nodes()
        G.add_node(new_node)
        G.add_edge(new_node, nodes_list[step % len(nodes_list)])
        G.add_edges_from(edges_to_add)
        
        num_nodes = G.number_of_nodes()
        num_edges = G.number_of_edges()
        growth_factor = num_edges / max(1, (num_edges - len(edges_to_add)))
        
        print(f"Step {step} | Nodes: {num_nodes} | Edges: {num_edges} | Growth Factor (G_n): {growth_factor:.2f}")

if __name__ == "__main__":
    run_relational_engine()